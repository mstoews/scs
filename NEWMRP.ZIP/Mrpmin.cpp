/*============================================================================*/
/* MRPMIN.C : MRP�W�J����Ҳ���۸���                                           */
/* �@�\�T�v : MRP�W�J�����̊�{�I�ȗ�����i��B                               */
/* �쐬��   : �s��                                                            */
/* �쐬��   : ��    ��                                                        */
/* �C����   : 1995.02.28                                                      */
/* �C����   : �k��  �O                                                        */
/*============================================================================*/
#define         WIN31                           // windows 3.1
#define         STRICT                          // strict type checking

#include "stdafx.h"
#include "MRP32.h"
#include "MainFrm.h"
#include "MRP32Doc.h"
#include "MRP32View.h"

#include "T4extern.h"


//#include    "t4struct.h"

//#include        "s3221020.h"


/*----------------------------------------------------------------------------*/
/* �֐���        : mrpWinWindow::RunMrp                                       */
/* �@�\�T�v      : mrpWinWindow�N���X�̃����o�B                               */
/*                 MRP�W�J�������s���B                                        */
/* ���o�͏��    : I/O Type      Id                   ���e                    */
/* �֐��l        : �Ȃ�                                                       */
/*----------------------------------------------------------------------------*/
void CMRP32Doc::RunMrp (void)
{
    long    s_r_mpsdno_N;
    char    s_r_type_C[CTSTR_LEN];
    long    s_r_curno_N;
    char    s_r_level_C[CTSTR_LEN];
    char    wbuf[CTSTR_LEN];
    long    s_r_days_N;
    long    s_r_fcstno_N;

    wmsMrpInit ();                                              // MRP���s��������

    //----- (�݌ɏ��������`��������)+1�̎Z�o -> s_r_days_N -----//

	CString strSeek;
	strSeek = wmsrCaleTyp;
	strSeek += s_r_fcstdt_D;

    strcpy (wmsrCTCode.buffer, wmsrCaleTyp);
    strcat (wmsrCTCode.buffer, s_r_fcstdt_D);
    wmsrCTCode.wa = WMS_WA_SMCALEM;
    if (x4seek (&t4smcalem.t4filter, wmsrCTCode.buffer) != 0) {
        wmsMrpExit ();
        return;
    }
    s_r_fcstno_N = f4long (t4smcalem.t4fdateno);                // �������Ԃ̒ʎZ��
    strcpy (wmsrCTCode.buffer, wmsrCaleTyp);
    strcat (wmsrCTCode.buffer, wmsrSysDate);
    wmsrCTCode.wa = WMS_WA_SMCALEM;
    if (x4seek (&t4smcalem.t4filter, wmsrCTCode.buffer) != 0) {
        wmsMrpExit ();
        return;
    }
    s_r_sysdno_N = f4long (t4smcalem.t4fdateno);                // �݌ɏ��������̒ʎZ��
    s_r_days_N   = s_r_fcstno_N - s_r_sysdno_N + 2;
    days_N       = s_r_days_N;
    n_N          = s_r_days_N;

    //----- �݌ɏ��������`�������ԕ��̔z��擾 -----//
    if (wmsAllocArray (n_N) == FALSE)
        return;

    //----- ���t��z��ɃZ�b�g -----//
    t4_s_datset (n_N);

    wmsrCTCode.wa = WMS_WA_SMPARTM;                             // �i�ڊ�l
    CTset_order (t4smpartm.ctref, 2);                           // �i��No.���L�[�̃C���f�b�N�X�I��

    //----- ���v�ʎc�ǂݍ��� -----//
    t4_s_rdtread ();

    //----- �l�q�o�i�̏��� -----//
    if (strcmp (s_r_mrpway_C, wmsSetStr(wbuf,"S",strlen(s_r_mrpway_C))) != 0) {
        t4_s_codread ();                                        // �󒍎c�̓ǂݍ���
        t4_s_irdread ();                                        // �Ɨ����v�c�̓ǂݍ���
    }

    //----- �K�v�̖����Ȃ���DBF�̃N���[�Y���V���ɕK�v��DBF�̃I�[�v�� -----//
    wmsOpenFile2 ();

    //----- MRPٰ�ߏ������� -----//
    wmsrCTCode.wa = WMS_WA_SMPARTM;
    CTset_order (t4smpartm.ctref, 1);                           // �L�[ : ���[���x���R�[�h
    x4top (&t4smpartm.t4filter);
    wmsDspInfo (GetResourceString(WMS_MSG09),"");    // �l�q�o�W�J������...
	
    //----- �l�q�o�W�J�����J�n (Ҳ�ð��� : �i�ڊ�l) -----//
    while (! d4eof(t4smpartm.ctref)) {
        //----- ���Ă̕i�ڊ�b�����擾 -----//
        wmsGetCurrentItemInfo (s_r_partno_C, s_r_level_C, s_r_mrpway_C, s_r_mpsflag_C);
        strcpy (s_r_way_C, s_r_mrpway_C);
        wmsDspItemCnt (s_r_partno_C, s_r_level_C);              // �i�ڏ����_���\��

        //----- �W�J���@�� MRP&���� �łȂ��A�W�J���@���Ⴄ�ꍇ -----//
        if (strcmp (s_r_mrpway_C, wmsSetStr(wbuf,"MS",strlen(s_r_mrpway_C))) != 0 && strcmp (f4str(t4smpartm.t4fmrpway), s_r_mrpway_C) != 0) {
            wmsrCTCode.wa = WMS_WA_SMPARTM;
            x4skip (&t4smpartm.t4filter, 1);
            continue;
        }
        //----- �t�@���g���i -----//
        if (strcmp (f4str(t4smpartm.t4fparttyp), wmsSetStr(wbuf, "C", f4len(t4smpartm.t4fparttyp))) == 0) {
            wmsrCTCode.wa = WMS_WA_SMPARTM;
            x4skip (&t4smpartm.t4filter, 1);
            continue;
        }
        //----- �W�J�i�ڂ�MPS�ɂ��\�菊�v�ʂe�ɂ������ꍇ�͎��̕i�ڂ� -----//
        if ((! (s_r_mpsend_N = t4_s_mps_search (s_r_partno_C, s_r_progcd_C))) && (! t4_s_req_search (s_r_partno_C))) {
            wmsrCTCode.wa = WMS_WA_SMPARTM;
            x4skip (&t4smpartm.t4filter, 1);
            continue;
        }

        //----- ���ĕi�ڂ̊�b�����擾 -----//
        wmsGetCurrentItemInfo2 (&s_r_curno_N, &s_r_qclt_N, s_r_unit_C, s_r_prmwcd_C, s_r_whcd_C, s_r_type_C, s_r_avlflg_C);

        //----- ���ĕi�ڂ̊�b�����擾(��z) -----//
        if (wmsGetCurrentItemOdrInfo (s_r_partno_C, s_r_odrule_C, &s_r_odrlt_N, &s_r_roundd_N, &s_r_minqty_F, &s_r_maxqty_F, &s_r_round_F, &s_r_odrdef_F) == FALSE) {
            wmsrCTCode.wa = WMS_WA_SMPARTM;
            x4skip (&t4smpartm.t4filter, 1);
            continue;
        }

        //----- ���W�J�i -----//
        if (strcmp (s_r_odrule_C, wmsSetStr(wbuf, "N", strlen(s_r_odrule_C))) == 0) {
            wmsrCTCode.wa = WMS_WA_SMPARTM;
            x4skip (&t4smpartm.t4filter, 1);
            continue;
        }

        //----- ���ĕi�ڂ̋����S�����������擾 -----//
        if (wmsGetCurrentItemSupplierInfo (f4str(t4smpartm.t4fsupplier), wmsrCaleTyp, s_r_pmflg_C) == FALSE) {
            wmsrCTCode.wa = WMS_WA_SMPARTM;
            x4skip (&t4smpartm.t4filter, 1);
            continue;
        }
        //strcpy (qc_caltyp_C,  wmsrCaleTyp);  // �������̶���ް����(default)   �� �����S�������̶���ް syuhei 96.07.24
        strcpy (qc_caltyp_C,  wmsrSysCTyp);    // �������̶���ް����(default)   �� ���т̶���ް //syuhei 96.07.24

        strcpy (s_r_whcdcl_C, wmsrCaleTyp);     // �݌ɏꏊ�̶���ް����(default) �� �����S�������̶���ް

        //----- ���ĕi�ڂ̊�b�����擾(����) -----//
        wmsGetCurrentItemQcInfo (s_r_partno_C, s_r_pmflg_C, qc_caltyp_C, &s_r_qclt_N);

        //----- ���ĕi�ڂ̍݌ɏꏊ�����擾 -----//
        if (wmsGetCurrentItemWhInfo (s_r_whcd_C, s_r_mrpavl_C, s_r_whcdcl_C) == FALSE) {
            wmsrCTCode.wa = WMS_WA_SMPARTM;
            x4skip (&t4smpartm.t4filter, 1);
            continue;
        }

        //----- �݌ɏ��������̶���ް�������� -----//
        wmsrCTCode.wa = WMS_WA_SMCALEM;
        CTset_order (t4smcalem.ctref, 1);               // NDX �� ����ް���� + ���t
        strcpy (wmsrCTCode.buffer, wmsrCaleTyp);
        strcat (wmsrCTCode.buffer, wmsrSysDate);
        if (x4seek (&t4smcalem.t4filter, wmsrCTCode.buffer) != 0) {
            // t4_s_SetMrpErr (WMS_MRPERR_CLT, s_r_partno_C, 0.0, wmsrSysDate); // syuhei 96.07.24
            t4_s_SetMrpErr (wmsrCaleTyp, s_r_partno_C, 0.0, wmsrSysDate);       // syuhei 96.07.24
            wmsrCTCode.wa = WMS_WA_SMPARTM;
            x4skip (&t4smpartm.t4filter, 1);
            continue;
        }
        s_r_sysdno_N = f4long (t4smcalem.t4fdateno);    // �� �݌ɏ���������long�l

        //----- �������Ԃ̶���ް�������� -----//
        wmsrCTCode.wa = WMS_WA_SMCALEM;
        strcpy (wmsrCTCode.buffer, wmsrCaleTyp);
        strcat (wmsrCTCode.buffer, s_r_fcstdt_D);
        if (x4seek (&t4smcalem.t4filter, wmsrCTCode.buffer) != 0) {
            //t4_s_SetMrpErr (WMS_MRPERR_CLT, s_r_partno_C, 0.0, s_r_fcstdt_D); // syuhei 96.07.24
            t4_s_SetMrpErr (wmsrCaleTyp, s_r_partno_C, 0.0, wmsrSysDate);        // syuhei 96.07.24
            wmsrCTCode.wa = WMS_WA_SMPARTM;
            x4skip (&t4smpartm.t4filter, 1);
            continue;
        }

        CTset_order (t4smpartm.ctref, 2);               // NDX �� �i��No.
        for (n_N = 1; n_N <= s_r_days_N; n_N++)         // ���P�ʂ�MPS�ر
            mps_F[n_N] = 0.0;

        //----- MPS��菊�v�ʂ�W�J���āA�I�[�_�[���쐬���� -----//
        if (s_r_mpsend_N == 1) {                        // MPS�L��̏ꍇ
            while (1) {
                //----- MPS���� -----//
                if ((s_r_mpsend_N = t4_s_mpsread (s_r_partno_C)) == 0)
                    break;
                //----- MPS���t�̶���ް���� -----//
                wmsrCTCode.wa = WMS_WA_SMCALEM;
                strcpy (wmsrCTCode.buffer, wmsrCaleTyp);
                strcat (wmsrCTCode.buffer, f4str(t4smmpsf.t4fmpsdate));
                if (x4seek (&t4smcalem.t4filter, wmsrCTCode.buffer) != 0) {
                   // t4_s_SetMrpErr (WMS_MRPERR_CLT, s_r_partno_C, f4double(t4smmpsf.t4fmpsqty), f4str(t4smmpsf.t4fmpsdate)); // syuhei 96.07.24
                   t4_s_SetMrpErr (wmsrCaleTyp, s_r_partno_C, f4double(t4smmpsf.t4fmpsqty), f4str(t4smmpsf.t4fmpsdate)); // syuhei 96.07.24
                    wmsrCTCode.wa = WMS_WA_SMMPSF;
                    x4skip (&t4smmpsf.t4filter, 1);
                    continue;
                }

                //----- �v��I�[�_�[�̍쐬 -----//
                s_r_mpsdno_N  = f4long (t4smcalem.t4fdateno);
                strcpy (s_r_seiban_C, f4str(t4smmpsf.t4fseiban));
                strcpy (s_r_cmpdat_D, f4str(t4smmpsf.t4fmpsdate));
                s_r_plnqty_F = f4double (t4smmpsf.t4fmpsqty);
                if (t4_s_crepln (s_r_partno_C, s_r_seiban_C, s_r_cmpdat_D, s_r_plnqty_F) < 0) {
                    wmsrCTCode.wa = WMS_WA_SMMPSF;
                    x4skip (&t4smmpsf.t4filter, 1);
                    continue;
                }
                wmsrCTCode.wa = WMS_WA_SMMPSF;

                //----- MPS��݂̾�� -----//
                wmsrCTCode.wa = WMS_WA_SMMPSF;
                if (date4long (wmsrSttDate) <= date4long(s_r_firmdt_D))
                    f4assign (t4smmpsf.t4fmpssign, "O");
                else
                    f4assign (t4smmpsf.t4fmpssign, "P");
                wmsSetUpdateDate ((FIELD4 *)NULL, (FIELD4 *)NULL, t4smmpsf.t4fupdtedt, t4smmpsf.t4fupdteusr, t4smmpsf.t4fupdteprg);

                //----- �v�浰�ް���q�i�ڂ̏��p�ʂ�W�J -----//
                if (wmsKoReqExp () < 0) {
                    wmsrCTCode.wa = WMS_WA_SMMPSF;
                    x4skip (&t4smmpsf.t4filter, 1);
                    continue;
                }

				if (strcmp (s_r_way_C, wmsSetStr(wbuf, "M", strlen(s_r_way_C))) == 0) {
                    n_N = s_r_mpsdno_N - s_r_sysdno_N + 2;
                    mps_F[n_N] = f4double (t4smmpsf.t4fmpsqty) + mps_F[n_N];
                }

                wmsrCTCode.wa = WMS_WA_SMMPSF;
                x4skip (&t4smmpsf.t4filter, 1);
            }
        }

        //----- ���v�ʂe���q�i�ڂ�W�J���āA�I�[�_�[���쐬���� -----//
        wmsrCTCode.wa = WMS_WA_SMREQPLN;
        if (x4seek (&t4smreqpln.t4filter, s_r_partno_C) == 0) {
            //----- �J�����g�i�ڂ̗\�菊�v�ʂ̏I�[�܂� -----//
            while (!d4eof(t4smreqpln.ctref) && (strcmp(f4str(t4smreqpln.t4fpartno),s_r_partno_C) == 0)) {
                strcpy (s_r_seiban_C, f4str(t4smreqpln.t4fseiban));
				strcpy (s_r_whcd_C,   f4str(t4smreqpln.t4fwhcd));
				for (n_N = 1; n_N <= s_r_days_N; n_N++)
					plo_F[n_N] = gr_F[n_N] = od_F[n_N] = vl_F[n_N] = rd_F[n_N] = 0.0;

				wmsrCTCode.wa = WMS_WA_SMPRTINV;
				s_r_safe_F    = 0.0;                // ���S�݌ɐ������l
				strcpy (wmsrCTCode.buffer, s_r_partno_C);
				strcat (wmsrCTCode.buffer, s_r_whcd_C);
				if (x4seek (&t4smprtinv.t4filter, wmsrCTCode.buffer) == 0) {
					s_r_chg_F = 1;
					if (strcmp (f4str(t4smprtinv.t4fperiodunt), wmsSetStr(wbuf, "DD", f4len(t4smprtinv.t4fperiodunt))) != 0) {
						strcpy (s_r_fromunit_C, f4str(t4smprtinv.t4fperiodunt));
						wmsSetStr (s_r_tounit_C, "DD", f4len(t4smprtinv.t4fperiodunt));
						t4_s_unitchg ();
					}
					vl_tim_N   = CTint (s_r_chg_F * f4double (t4smprtinv.t4favlperiod));
													// ���S�݌ɐ��ݒ�
					s_r_safe_F = f4double (t4smprtinv.t4fsafestock);
				}
				else
					vl_tim_N = 0;

				wmsrCTCode.wa = WMS_WA_SMREQPLN;

				if (strcmp (s_r_way_C, wmsSetStr(wbuf,"S",strlen(s_r_way_C))) == 0) {
					s_r_safe_F = 0.0;               // ���S�݌ɐ������l
					strcpy (s_r_mrpavl_C, "N");
					strcpy (s_r_avlflg_C, "N");
					strcpy (s_r_odrule_C, "L");
					t4_s_greqset ();                // �����v�ʃZ�b�g
					wmsrCTCode.wa = WMS_WA_SMREQPLN;
					x4skip (&t4smreqpln.t4filter, -1);
					s_r_recno_N = d4recno(t4smreqpln.ctref);
					s_r_ohqty_F = 0.0;

					n_vl_N = 0;
					t4_s_modread ();                //  [�m�萻�����ް���] seihinn no toki all whcd no tall??
					t4_s_podread ();                //  [�m��w�����ް���]

					s_r_invqty_F = od_F[1] - rd_F[1] + s_r_ohqty_F;

					n_N = 2;
					while (1) {
						s_r_nrqty_F = 0.0;
						s_r_nm_N = n_N;
						vl_qty_F = gr_F[n_N] + rd_F[n_N];

						if (t4_s_nrset () < 0)      // �������v�ʌv�Z
							break;

						if (s_r_nrqty_F > 0.0) {    // �s�Ǘ��L��
							s_r_reqqty_F = ((1.0 - s_r_odrdef_F) == 0.0) ? 0.0 : s_r_nrqty_F / (1.0 - s_r_odrdef_F);
							m_N = CTint(n_N);
							if (t4_s_mrpcl () < 0)  // �v��I�[�_�[�v�Z�ƍ쐬
								break;
						}

						n_N = s_r_nm_N;
						if (date4long(dte_D[n_N]) == date4long(s_r_fcstdt_D))
							break;

						n_N = n_N + 1;
						wmsrCTCode.wa = WMS_WA_SMCALEM;
						CTset_order(t4smcalem.ctref,1);
						strcpy (wmsrCTCode.buffer, wmsrCaleTyp);
						strcat (wmsrCTCode.buffer, dte_D[n_N]);
						if (x4seek (&t4smcalem.t4filter, wmsrCTCode.buffer) != 0)
							break;
						if (date4long(f4str(t4smcalem.t4fdate)) > date4long(s_r_fcstdt_D)  ||  strcmp(f4str(t4smcalem.t4fcaletype),wmsrCaleTyp) != 0)
							break;
					}

					wmsrCTCode.wa = WMS_WA_SMREQPLN;
					d4go (t4smreqpln.ctref, s_r_recno_N);
					x4skip (&t4smreqpln.t4filter, 1);
				}
				else {
					// �l�q�o�L���݌ɔF���敪�`�F�N
					wmsrCTCode.wa = WMS_WA_SMSECTM;
					if (x4seek (&t4smsectm.t4filter, s_r_whcd_C) != 0)
						wmsSetStr (s_r_mrpavl_C, "N", f4len(t4smsectm.t4fmrpavlflg));
					else
						strcpy (s_r_mrpavl_C, f4str(t4smsectm.t4fmrpavlflg));

					// [�����v��ð��كZ�b�g AND RD SET]
					t4_s_greqset ();

					wmsrCTCode.wa = WMS_WA_SMREQPLN;
					x4skip (&t4smreqpln.t4filter, -1);
					s_r_recno_N = d4recno(t4smreqpln.ctref);
					wmsSetStr (s_r_seiban_C, "**********", f4len(t4smreqpln.t4fseiban));
					s_r_ohqty_F = 0.0;
					t4_s_modread ();    //  [�m�萻�����ް���] seihinn no toki all whcd no tall??
					t4_s_podread ();    //  [�m��w�����ް���]

					wmsrCTCode.wa = WMS_WA_SMINVDTF;

                    s_r_invqty_F = od_F[1] - rd_F[1] + s_r_ohqty_F;
                    strcpy (wbuf, s_r_odrule_C);
                    if (CTcontain (CTltrim(CTrtrim(wbuf)), "LBP")) {    // �ʃ��b�g�@
                        n_N = 2;
                        while (1) {
                            //----- �L���݌Ƀ`�F�b�N -----//
                            vl_qty_F = gr_F[n_N] + rd_F[n_N];
                            s_r_ohqty_F = 0.0;              // �L���݌ɏ����l�ݒ�
                                // �L���݌�����(��ʑI��) = ���Ȃ�
                            if (strcmp(s_r_invchk_C, wmsSetStr(wbuf, "Y", strlen(s_r_invchk_C))) != 0)
                                s_r_safe_F = 0.0;           // ���S�݌ɖ���
                                // �L���݌������敪(�i�ڊM) = ���Ȃ�
                            else if (strcmp(s_r_avlflg_C, wmsSetStr(wbuf, "Y", strlen(s_r_avlflg_C))) != 0)
                                s_r_safe_F = 0.0;           // ���S�݌ɖ���
                                // �݌ɔF���敪(�݌ɏꏊ) = ���Ȃ�
                            else if (strcmp(s_r_mrpavl_C, wmsSetStr(wbuf, "Y", strlen(s_r_mrpavl_C))) != 0)
                                s_r_safe_F = 0.0;           // ���S�݌ɖ���
                            else {
                                //----- �J�����g�i�ڂ̍݌ɖ��ׂ����� -----//
                                wmsrCTCode.wa = WMS_WA_SMINVDTF;
                                strcpy (wmsrCTCode.buffer, s_r_partno_C);
                                strcat (wmsrCTCode.buffer, s_r_whcd_C);
                                x4seek (&t4sminvdtf.t4filter, wmsrCTCode.buffer);
                                //----- �݌ɖ��ׂ̏I�[�܂� -----//
                                while (
                                    (! d4eof (t4sminvdtf.ctref))                              &&
                                    (strcmp (f4str(t4sminvdtf.t4fpartno), s_r_partno_C) == 0) &&
                                    (strcmp (f4str(t4sminvdtf.t4fwhcd),   s_r_whcd_C) == 0)   &&
                                    (date4long(f4str(t4sminvdtf.t4fvaliddte)) <= date4long(dte_D[n_N]))
                                ) {
                                    if (date4long (f4str(t4sminvdtf.t4fexpirddte)) > date4long(dte_D[n_N]) || strcmp(f4str(t4sminvdtf.t4fexpirddte),wmsrNullDate) == 0) {
                                        s_r_ohqty_F = s_r_ohqty_F + f4double(t4sminvdtf.t4fohqty);
                                        if (f4double(t4sminvdtf.t4fohqty) <= vl_qty_F) {
                                            vl_qty_F = vl_qty_F - f4double(t4sminvdtf.t4fohqty);
                                            f4assign_double (t4sminvdtf.t4fohqty, 0.0);
                                        }
                                        else {
                                            vl_qty_F = f4double(t4sminvdtf.t4fohqty) - vl_qty_F;
                                            f4assign_double (t4sminvdtf.t4fohqty, vl_qty_F);
                                            vl_qty_F = 0.0;
                                        }
                                    }
                                    else
                                        f4assign_double (t4sminvdtf.t4fohqty, 0.0);
                                    wmsrCTCode.wa = WMS_WA_SMINVDTF;
                                    x4skip (&t4sminvdtf.t4filter, 1);
                                }
                            }

                            s_r_nrqty_F = 0.0;
                            s_r_nm_N    = n_N;

                            if (t4_s_nrset () < 0)      // �������v�ʌv�Z
                                break;

                            if (s_r_nrqty_F > 0.0) {    // �s�Ǘ��L��
                                s_r_reqqty_F = ((1.0 - s_r_odrdef_F) == 0.0) ? 0.0 : s_r_nrqty_F / (1.0 - s_r_odrdef_F);
                                m_N = CTint(n_N);
                                if (t4_s_mrpcl () < 0)
                                    break;
                            }

                            n_N = s_r_nm_N;

                            if (date4long(dte_D[n_N]) == date4long(s_r_fcstdt_D))
                                break;

                            n_N = n_N + 1;
                            wmsrCTCode.wa = WMS_WA_SMCALEM;
                            CTset_order (t4smcalem.ctref, 1);
                            strcpy(wmsrCTCode.buffer, wmsrCaleTyp);
                            strcat(wmsrCTCode.buffer, dte_D[n_N]);
                            if (x4seek (&t4smcalem.t4filter, wmsrCTCode.buffer) != 0)
                                break;

                            if(date4long(f4str(t4smcalem.t4fdate)) > date4long(s_r_fcstdt_D)  ||  strcmp(f4str(t4smcalem.t4fcaletype),wmsrCaleTyp) != 0)
                                break;
                        }
                    }
                    wmsrCTCode.wa = WMS_WA_SMREQPLN;
                    d4go (t4smreqpln.ctref, s_r_recno_N);
                    x4skip (&t4smreqpln.t4filter, 1);
                }
            }
        }
        wmsrCTCode.wa = WMS_WA_SMPARTM;
        CTset_order (t4smpartm.ctref, 1);
        d4go (t4smpartm.ctref, s_r_curno_N);
        x4skip (&t4smpartm.t4filter, 1);
    }

    //----- �\�菊�v�ʂe�̖����f�[�^���폜 -----//
    /*
    if (wmsErsNgDataFromReqPln () < 0) {
        wmsMrpExit ();
        return;
    }
    */

    //----- ���v�ʓW�J�����e�X�V -----//
    t4_s_mrphst (s_r_level_C);
    wmsMrpExit ();
}
/*=====< At Eof MRPMIN.C >====================================================*/
