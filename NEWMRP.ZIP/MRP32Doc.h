// MRP32Doc.h : interface of the CMRP32Doc class
//
/////////////////////////////////////////////////////////////////////////////
class CMRP32View;

class CMRP32Doc : public CDocument
{
private:
	
   long oldLevel;
protected: // create from serialization only

   CMRP32Doc();
   DECLARE_DYNCREATE(CMRP32Doc)

public:
   void RunMrp (void);
   CString GetResourceString (int);
   void wmsMrpInit (void);
   void wmsMrpExit (void);
   void wmsGetCurrentItemInfo (char *, char *, char *, char *);
   void wmsGetCurrentItemInfo2 (long *, long *, char *, char *, char *, char *, char *);
   BOOL wmsGetCurrentItemOdrInfo (char *, char *, long *, long *, double *, double *, double *, double *);
   BOOL wmsGetCurrentItemSupplierInfo (char *, char *, char *);
   void wmsGetCurrentItemQcInfo (char *, char *, char *, long *);
   BOOL wmsGetCurrentItemWhInfo (char *, char *, char *);
   void wmsDspInfo (CString Msg,CString sub);
   
   void wmsDspItemCnt (char *, char *);
   BOOL wmsAllocArray (int);
   void wmsFreeArray (void);
   void wmsZap (DATA4 *);
   void wmsOpenFile (void);
   void wmsOpenFile2 (void);
   void t4_s_datset (long);
   void t4_s_rdtread (void);
   void t4_s_codread (void);
   void t4_s_irdread (void);
   long t4_s_mps_search (char *, char *);
   long t4_s_req_search (char *);
   long t4_s_mpsread (char *);
   int  t4_s_crepln (char *, char *, char *, double);
   int  wmsKoReqExp (void);
   int  t4_s_mrpcl (void);
   void t4_s_greqset (void);
   void t4_s_modread (void);
   void t4_s_podread (void);
   int  t4_s_nrset (void);
   void t4_s_mrphst (char *);
   void t4_s_unitchg (void);
   int  wmsChkMrpWay (char *);
   int  wmsLTSet (char *, char *, char *, long);
   int  wmsWDateSet (char *, char *, char *, long);
   void t4_s_SetMrpErr (char *, char *, double, char *);
   
   double wmsRoundQty (double , int );
   double wmsRaiseQty (double , int );

//    int  wmsErsNgDataFromReqPln (void);
   char *wmsSetStr (char *, char *, unsigned int);
   char *wmsDate4Assign (char *, long);
   char *wmsDate4Today (char *);
   char *wmsDate4Time_Now (char *);
   void wmsSetUpdateDate (FIELD4 *, FIELD4 *, FIELD4 *, FIELD4 *, FIELD4 *);
// in T4USE.C
   void t4use_smmpsf (char *, int);
   void t4use_smsectm (char *, int);
   void t4use_smsectty (char *, int);
   void t4use_smprtqcm (char *, int);
   void t4use_sminvf (char *, int);
   void t4use_sminvdtf (char *, int);
   void t4use_smprtinv (char *, int);
   void t4use_smprtodr (char *, int);
   void t4use_smplnodr (char *, int);
   void t4use_smcalem (char *, int);
   void t4use_smpartm (char *, int);
   void t4use_smreqpln (char *, int);
   void t4use_smbuckm (char *, int);
   void t4use_smmorlsf (char *, int);
   void t4use_smuexchg (char *, int);
   void t4use_smreqdtf (char *, int);
   void t4use_smporlsf (char *, int);
   void t4use_smmrperr (char *, int);
   void t4use_smsystem (char *, int);
   void t4use_smmrphst (char *, int);
   void t4use_smstrctm (char *, int);
   void t4use_smcodrf (char *, int);
   void t4use_smidepf (char *, int);




// Attributes
public:
	CMRP32View* pView;
// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMRP32Doc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMRP32Doc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CMRP32Doc)
	afx_msg void OnAddTable();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
