/*============================================================================*/
/* T4USE.C  : MRP�W�J����DBF�����                                             */
/* �@�\�T�v : MRP�W�J�����Ŏg�p����A�eDBF����݂���֐����W�񂵂�̧��       */
/* �쐬��   : �s��                                                            */
/* �쐬��   : ��    ��                                                        */
/* �C����   : 1995.02.28                                                      */
/* �C����   : �k��  �O                                                        */
/*============================================================================*/

#include "stdafx.h"
#include "MRP32.h"
#include "MainFrm.h"
#include "MRP32Doc.h"
#include "MRP32View.h"

#include "t4extern.h"

extern CODE4        wmsrCodebase;   



/*----------------------------------------------------------------------------*/
/* �֐���        : t4use_smmpsf                                               */
/* �@�\�T�v      : ����Y�v��e�̃I�[�v��                                   */
/* ���o�͏��    : I/O Type      Id                   ���e                    */
/*                 I   char     *smmpsf_C             ����Y�v���DBF̧�ٖ� */
/*                 I   int      exclusive             ۯ����邩�ǂ���         */
/* �֐��l        : �Ȃ�                                                       */
/*----------------------------------------------------------------------------*/
void CMRP32Doc::t4use_smmpsf (char *smmpsf_C, int exclusive)
{
    wmsDspInfo (GetResourceString(WMS_MSG11), smmpsf_C);
    t4smmpsf.ctref = d4open (&wmsrCodebase, smmpsf_C);
    if (wmsrCTCode.exclusive || exclusive)
        d4lock_file (t4smmpsf.ctref);
    t4smmpsf.t4fpartno   = d4field (t4smmpsf.ctref, "FITEMNO");
    t4smmpsf.t4fmpsdate  = d4field (t4smmpsf.ctref, "FMPSDATE");
    t4smmpsf.t4fseiban   = d4field (t4smmpsf.ctref, "FPRJNO");
    t4smmpsf.t4fmpsqty   = d4field (t4smmpsf.ctref, "FMPSQTY");
    t4smmpsf.t4fmfgsect  = d4field (t4smmpsf.ctref, "FMFGSECT");
    t4smmpsf.t4fmpssign  = d4field (t4smmpsf.ctref, "FMPSSIGN");
    t4smmpsf.t4fupdtedt  = d4field (t4smmpsf.ctref, "FUPDTEDT");
    t4smmpsf.t4fupdteusr = d4field (t4smmpsf.ctref, "FUPDTEUSR");
    t4smmpsf.t4fupdteprg = d4field (t4smmpsf.ctref, "FUPDTEPRG");
    t4smmpsf.filter_relate.filter = NULL;
    t4smmpsf.filter_relate.relate = NULL;
    t4smmpsf.filter_relate.data   = t4smmpsf.ctref;
    d4top (t4smmpsf.ctref);
    x4init (&t4smmpsf.t4filter, t4smmpsf.ctref, CTfilter_relate, (void *)&t4smmpsf.filter_relate);
    wmsrCTCode.alias[wmsrCTCode.wa] = t4smmpsf.ctref;
    d4optimize (t4smmpsf.ctref, 1);
}

/*----------------------------------------------------------------------------*/
/* �֐���        : t4use_smsectm                                              */
/* �@�\�T�v      : �����l�̃I�[�v��                                           */
/* ���o�͏��    : I/O Type      Id                   ���e                    */
/*                 I   char     *smsectm_C            �����lDBF̧�ٖ�         */
/*                 I   int      exclusive             ۯ����邩�ǂ���         */
/* �֐��l        : �Ȃ�                                                       */
/*----------------------------------------------------------------------------*/
void CMRP32Doc::t4use_smsectm (char *smsectm_C, int exclusive)
{
    wmsDspInfo (GetResourceString(WMS_MSG11), smsectm_C);
    t4smsectm.ctref = d4open( &wmsrCodebase, smsectm_C );
    if (wmsrCTCode.exclusive || exclusive)
        d4lock_file( t4smsectm.ctref );
    t4smsectm.t4fsectcd    = d4field (t4smsectm.ctref, "FSECTCD");
    t4smsectm.t4fsecttyp   = d4field (t4smsectm.ctref, "FSECTTYP");
    t4smsectm.t4fcaletype  = d4field (t4smsectm.ctref, "FCALETYPE");
    t4smsectm.t4fmrpavlflg = d4field (t4smsectm.ctref, "FMRPAVLFLG");
    t4smsectm.filter_relate.filter = NULL;
    t4smsectm.filter_relate.relate = NULL;
    t4smsectm.filter_relate.data   = t4smsectm.ctref;
    d4top( t4smsectm.ctref );
    x4init( &t4smsectm.t4filter, t4smsectm.ctref, CTfilter_relate, (void *)&t4smsectm.filter_relate );
    wmsrCTCode.alias[wmsrCTCode.wa] = t4smsectm.ctref;
    d4optimize(t4smsectm.ctref,1);
}

/*----------------------------------------------------------------------------*/
/* �֐���        : t4use_sminvdtf                                             */
/* �@�\�T�v      : �݌ɖ��ׂe�̃I�[�v��                                       */
/* ���o�͏��    : I/O Type      Id                   ���e                    */
/*                 I   char     *smsectm_C            �����lDBF̧�ٖ�         */
/*                 I   int      exclusive             ۯ����邩�ǂ���         */
/* �֐��l        : �Ȃ�                                                       */
/*----------------------------------------------------------------------------*/
void CMRP32Doc::t4use_sminvdtf (char *sminvdtf_C, int exclusive)
{
    wmsDspInfo (GetResourceString(WMS_MSG11), sminvdtf_C);
    t4sminvdtf.ctref = d4open( &wmsrCodebase, sminvdtf_C );
    if (wmsrCTCode.exclusive || exclusive)
        d4lock_file( t4sminvdtf.ctref );
    t4sminvdtf.t4fpartno    = d4field (t4sminvdtf.ctref, "FITEMNO");
    t4sminvdtf.t4fwhcd      = d4field (t4sminvdtf.ctref, "FWHCD");
    t4sminvdtf.t4fvaliddte  = d4field (t4sminvdtf.ctref, "FVALIDDTE");
    t4sminvdtf.t4fexpirddte = d4field (t4sminvdtf.ctref, "FEXPIRDDTE");
    t4sminvdtf.t4fohqty     = d4field (t4sminvdtf.ctref, "FOHQTY");
    t4sminvdtf.filter_relate.filter = NULL;
    t4sminvdtf.filter_relate.relate = NULL;
    t4sminvdtf.filter_relate.data   = t4sminvdtf.ctref;
    d4top( t4sminvdtf.ctref );
    x4init( &t4sminvdtf.t4filter, t4sminvdtf.ctref, CTfilter_relate, (void *)&t4sminvdtf.filter_relate );
    wmsrCTCode.alias[wmsrCTCode.wa] = t4sminvdtf.ctref;
    d4optimize(t4sminvdtf.ctref,1);
}

/*----------------------------------------------------------------------------*/
/* �֐���        : t4use_smprtinv                                             */
/* �@�\�T�v      : �i�ڍ݌ɊǗ���l�̃I�[�v��                               */
/* ���o�͏��    : I/O Type      Id                   ���e                    */
/*                 I   char     *smprtinv_C           �i�ڍ݌ɊǗ��MDBF��  */
/*                 I   int      exclusive             ۯ����邩�ǂ���         */
/* �֐��l        : �Ȃ�                                                       */
/*----------------------------------------------------------------------------*/
void CMRP32Doc::t4use_smprtinv (char *smprtinv_C, int exclusive)
{
    wmsDspInfo (GetResourceString(WMS_MSG11), smprtinv_C);
    t4smprtinv.ctref = d4open (&wmsrCodebase, smprtinv_C);
    if (wmsrCTCode.exclusive || exclusive)
        d4lock_file (t4smprtinv.ctref);
    t4smprtinv.t4fpartno    = d4field (t4smprtinv.ctref, "FITEMNO");
    t4smprtinv.t4fwhcd      = d4field (t4smprtinv.ctref, "FWHCD");
    t4smprtinv.t4fsafestock = d4field (t4smprtinv.ctref, "FSAFESTOCK");
    t4smprtinv.t4favlperiod = d4field (t4smprtinv.ctref, "FAVLPERIOD");
    t4smprtinv.t4fperiodunt = d4field (t4smprtinv.ctref, "FPERIODUNT");
    t4smprtinv.filter_relate.filter = NULL;
    t4smprtinv.filter_relate.relate = NULL;
    t4smprtinv.filter_relate.data   = t4smprtinv.ctref;
    d4top (t4smprtinv.ctref);
    x4init (&t4smprtinv.t4filter, t4smprtinv.ctref, CTfilter_relate, (void *)&t4smprtinv.filter_relate);
    wmsrCTCode.alias[wmsrCTCode.wa] = t4smprtinv.ctref;
    d4optimize (t4smprtinv.ctref, 1);
}

/*----------------------------------------------------------------------------*/
/* �֐���        : t4use_smsectty                                             */
/* �@�\�T�v      : �����^�C�v�s�̃I�[�v��                                     */
/* ���o�͏��    : I/O Type      Id             ���e                          */
/*                 I   char     *smsectty_C     �����^�C�v�sDBF��             */
/*                 I   int      exclusive       ۯ����邩�ǂ���               */
/* �֐��l        : �Ȃ�                                                       */
/*----------------------------------------------------------------------------*/
void CMRP32Doc::t4use_smsectty (char *smsectty_C, int exclusive)
{
    wmsDspInfo (GetResourceString(WMS_MSG11), smsectty_C);
    t4smsectty.ctref = d4open(&wmsrCodebase, smsectty_C);
    if (wmsrCTCode.exclusive || exclusive)
        d4lock_file( t4smsectty.ctref );
    t4smsectty.t4fsecttyp = d4field (t4smsectty.ctref, "FSECTTYP");
    t4smsectty.t4fsectcls = d4field (t4smsectty.ctref, "FSECTCLS");
    t4smsectty.filter_relate.filter = NULL;
    t4smsectty.filter_relate.relate = NULL;
    t4smsectty.filter_relate.data   = t4smsectty.ctref;
    d4top( t4smsectty.ctref );
    x4init( &t4smsectty.t4filter, t4smsectty.ctref, CTfilter_relate, (void *)&t4smsectty.filter_relate );
    wmsrCTCode.alias[wmsrCTCode.wa] = t4smsectty.ctref;
    d4optimize(t4smsectty.ctref,1);
}

/*----------------------------------------------------------------------------*/
/* �֐���        : t4use_smprtqcm                                             */
/* �@�\�T�v      : �i�ڌ�����l�̃I�[�v��                                   */
/* ���o�͏��    : I/O Type      Id             ���e                          */
/*                 I   char     *smprtqcm_C     �i�ڌ�����l��DBF��         */
/*                 I   int      exclusive       ۯ����邩�ǂ���               */
/* �֐��l        : �Ȃ�                                                       */
/*----------------------------------------------------------------------------*/
void CMRP32Doc::t4use_smprtqcm (char *smprtqcm_C, int exclusive)
{
    wmsDspInfo (GetResourceString(WMS_MSG11), smprtqcm_C);
    t4smprtqcm.ctref = d4open (&wmsrCodebase, smprtqcm_C);
    if (wmsrCTCode.exclusive || exclusive)
        d4lock_file (t4smprtqcm.ctref);
    t4smprtqcm.t4fpartno = d4field (t4smprtqcm.ctref, "FITEMNO");
    t4smprtqcm.t4fqcsect = d4field (t4smprtqcm.ctref, "FQCSECT");
    t4smprtqcm.filter_relate.filter = NULL;
    t4smprtqcm.filter_relate.relate = NULL;
    t4smprtqcm.filter_relate.data   = t4smprtqcm.ctref;
    d4top( t4smprtqcm.ctref );
    x4init( &t4smprtqcm.t4filter, t4smprtqcm.ctref, CTfilter_relate, (void *)&t4smprtqcm.filter_relate );
    wmsrCTCode.alias[wmsrCTCode.wa] = t4smprtqcm.ctref;
    d4optimize(t4smprtqcm.ctref,1);
}

/*----------------------------------------------------------------------------*/
/* �֐���        : t4use_smprtodr                                             */
/* �@�\�T�v      : �i�ڎ�z�Ǘ���l�̃I�[�v��                               */
/* ���o�͏��    : I/O Type      Id             ���e                          */
/*                 I   char     *smprtodr_C     �i�ڎ�z�Ǘ���l��DBF��     */
/*                 I   int      exclusive       ۯ����邩�ǂ���               */
/* �֐��l        : �Ȃ�                                                       */
/*----------------------------------------------------------------------------*/
void CMRP32Doc::t4use_smprtodr (char *smprtodr_C, int exclusive)
{
    wmsDspInfo (GetResourceString(WMS_MSG11), smprtodr_C);
    t4smprtodr.ctref = d4open (&wmsrCodebase, smprtodr_C);	
	if(wmsrCodebase.errorCode >= 0)	
	{
		if (wmsrCTCode.exclusive || exclusive)
        d4lock_file (t4smprtodr.ctref);
		t4smprtodr.t4fpartno    = d4field (t4smprtodr.ctref, "FITEMNO");
		t4smprtodr.t4fodrrule   = d4field (t4smprtodr.ctref, "FODRRULE");
		t4smprtodr.t4fminodrqty = d4field (t4smprtodr.ctref, "FMINODRQTY");
		t4smprtodr.t4fmaxodrqty = d4field (t4smprtodr.ctref, "FMAXODRQTY");
		t4smprtodr.t4froundqty  = d4field (t4smprtodr.ctref, "FROUNDQTY");
		t4smprtodr.t4frounddays = d4field (t4smprtodr.ctref, "FROUNDDAYS");
		t4smprtodr.t4fodrunit   = d4field (t4smprtodr.ctref, "FODRUNIT");
		t4smprtodr.t4fodrdef    = d4field (t4smprtodr.ctref, "FODRDEF");
		t4smprtodr.t4fodrlt     = d4field (t4smprtodr.ctref, "FODRLT");
		t4smprtodr.filter_relate.filter = NULL;
		t4smprtodr.filter_relate.relate = NULL;
		t4smprtodr.filter_relate.data   = t4smprtodr.ctref;
		d4top( t4smprtodr.ctref );
		x4init( &t4smprtodr.t4filter, t4smprtodr.ctref, CTfilter_relate, (void *)&t4smprtodr.filter_relate );
		wmsrCTCode.alias[wmsrCTCode.wa] = t4smprtodr.ctref;
		d4optimize(t4smprtodr.ctref,1);
	}
	else
	{
		CString strError(e4text(wmsrCodebase.errorCode));
		CString strMsg("Database error:\n");
		strMsg += strError;
		MessageBox(GetFocus(),strMsg,"MRP",MB_OK);
		return;

	}

}

/*----------------------------------------------------------------------------*/
/* �֐���        : t4use_smplnodr                                             */
/* �@�\�T�v      : �v��I�[�_�[�e�̃I�[�v��                                   */
/* ���o�͏��    : I/O Type      Id             ���e                          */
/*                 I   char     *smplnodr_C     �v��I�[�_�[��DBF��           */
/*                 I   int      exclusive       ۯ����邩�ǂ���               */
/* �֐��l        : �Ȃ�                                                       */
/*----------------------------------------------------------------------------*/
void CMRP32Doc::t4use_smplnodr (char *smplnodr_C, int exclusive)
{
    wmsDspInfo (GetResourceString(WMS_MSG11), smplnodr_C);
	
	/**
	The following is some test code to make sure the database was
	opened correctly.

	Data4 dbf;	
	Code4 cb;
	cb.init();
	cb.autoOpen = FALSE;
	wmsrCodebase.autoOpen = FALSE;
	int rc = dbf.open(cb,smplnodr_C);
	dbf.top();
	Field4 fpartno(dbf,1);
	Field4 fseiban(dbf,2);
	Field4 fwhcd(dbf,3);
	Field4 fstartdte(dbf,4);
	Field4 fduedte(dbf,5);
	Field4 fpmodrflg(dbf,6);
	Field4 fplanqty(dbf,7);	
	Field4 fsupplyreq(dbf,8);
	Field4 fentdt(dbf,9);
	Field4 fentusr(dbf,10);
	Field4 fupdtedt(dbf,11);
	Field4 fupdteusr(dbf,12);
	Field4 fupdteprg(dbf,13);
	
	CString strFpartno = fpartno.name();
	dbf.close();
	**/
	
	t4smplnodr.ctref = d4open (&wmsrCodebase, smplnodr_C);
	int error = wmsrCodebase.errorCode;

    //if (wmsrCTCode.exclusive || exclusive)
    //    d4lock_file (t4smplnodr.ctref);
    error = wmsrCodebase.errorCode;
    t4smplnodr.t4fpartno    = d4field_j (t4smplnodr.ctref,1); //"FITEMNO");
    t4smplnodr.t4fseiban    = d4field_j (t4smplnodr.ctref,2); //"FPRJNO");
    t4smplnodr.t4fstartdte  = d4field_j (t4smplnodr.ctref,3); //"FSTARTDTE");
    t4smplnodr.t4fduedte    = d4field_j (t4smplnodr.ctref,5); //"FDUEDTE");
    t4smplnodr.t4fpmodrflg  = d4field_j (t4smplnodr.ctref,6); //"FPMODRFLG");
    t4smplnodr.t4fplanqty   = d4field_j (t4smplnodr.ctref,7); //"FPLANQTY");
    t4smplnodr.t4fwhcd      = d4field_j (t4smplnodr.ctref,4); //"FWHCD");
    t4smplnodr.t4fsupplyreq = d4field_j (t4smplnodr.ctref,8); //"FSUPPLYREQ");
    t4smplnodr.t4fentdt     = d4field_j (t4smplnodr.ctref,12); //"FENTDT");
    t4smplnodr.t4fentusr    = d4field_j (t4smplnodr.ctref,13); //"FENTUSR");
    t4smplnodr.t4fupdtedt   = d4field_j (t4smplnodr.ctref,14); //"FUPDTEDT");
    t4smplnodr.t4fupdteusr  = d4field_j (t4smplnodr.ctref,15); //"FUPDTEUSR");
    t4smplnodr.t4fupdteprg  = d4field_j (t4smplnodr.ctref,16); //"FUPDTEPRG");
	error = wmsrCodebase.errorCode;
    t4smplnodr.filter_relate.filter = NULL;
    t4smplnodr.filter_relate.relate = NULL;
    t4smplnodr.filter_relate.data   = t4smplnodr.ctref;
    d4top (t4smplnodr.ctref);
    x4init (&t4smplnodr.t4filter, t4smplnodr.ctref, CTfilter_relate, (void *)&t4smplnodr.filter_relate);
    wmsrCTCode.alias[wmsrCTCode.wa] = t4smplnodr.ctref;
    d4optimize(t4smplnodr.ctref,1);
	if(wmsrCodebase.errorCode < 0)
	{
		CString strError(e4text(error));
		CString strMsg("Database error:\n");
		strMsg += strError;
		MessageBox(GetFocus(),strMsg,"MRP",MB_OK);
		return;
	}

}

/*----------------------------------------------------------------------------*/
/* �֐���        : t4use_smsectty                                             */
/* �@�\�T�v      : �����^�C�v�s�̃I�[�v��                                     */
/* ���o�͏��    : I/O Type      Id             ���e                          */
/*                 I   char     *smsectty_C     �����^�C�v�sDBF��             */
/*                 I   int      exclusive       ۯ����邩�ǂ���               */
/* �֐��l        : �Ȃ�                                                       */
/*----------------------------------------------------------------------------*/
void CMRP32Doc::t4use_smcalem( char *smcalem_C, int exclusive )
{
    wmsDspInfo (GetResourceString(WMS_MSG11), smcalem_C);
    t4smcalem.ctref = d4open( &wmsrCodebase, smcalem_C );
    if ( wmsrCTCode.exclusive || exclusive )
        d4lock_file( t4smcalem.ctref );
    t4smcalem.t4fcaletype  = d4field (t4smcalem.ctref, "FCALETYPE");
    t4smcalem.t4fdate      = d4field (t4smcalem.ctref, "FDATE");
    t4smcalem.t4fholidayfl = d4field (t4smcalem.ctref, "FHOLIDAYFL");
    t4smcalem.t4fdateseq   = d4field (t4smcalem.ctref, "FDATESEQ");
    t4smcalem.t4fdateno    = d4field (t4smcalem.ctref, "FDATENO");
    t4smcalem.t4fkikanno   = d4field (t4smcalem.ctref, "FKIKANNO");
    t4smcalem.filter_relate.filter = NULL;
    t4smcalem.filter_relate.relate = NULL;
    t4smcalem.filter_relate.data   = t4smcalem.ctref;
    d4top( t4smcalem.ctref );
    x4init( &t4smcalem.t4filter, t4smcalem.ctref, CTfilter_relate, (void *)&t4smcalem.filter_relate );
    wmsrCTCode.alias[wmsrCTCode.wa] = t4smcalem.ctref;
    d4optimize(t4smcalem.ctref,1);
}

/*----------------------------------------------------------------------------*/
/* �֐���        : t4use_smpartm                                              */
/* �@�\�T�v      : �i�ڊ�l�̃I�[�v��                                       */
/* ���o�͏��    : I/O Type      Id             ���e                          */
/*                 I   char     *smpartm_C      �i�ڊ�lDBF��               */
/*                 I   int      exclusive       ۯ����邩�ǂ���               */
/* �֐��l        : �Ȃ�                                                       */
/*----------------------------------------------------------------------------*/
void CMRP32Doc::t4use_smpartm (char *smpartm_C, int exclusive)
{
    wmsDspInfo (GetResourceString(WMS_MSG11), smpartm_C);
    t4smpartm.ctref = d4open( &wmsrCodebase, smpartm_C );
    if ( wmsrCTCode.exclusive || exclusive )
        d4lock_file( t4smpartm.ctref );
    t4smpartm.t4fpartno    = d4field (t4smpartm.ctref, "FITEMNO");
    t4smpartm.t4fsupplier  = d4field (t4smpartm.ctref, "FSUPPLIER");
    t4smpartm.t4fprmwhcd   = d4field (t4smpartm.ctref, "FPRMWHCD");
    t4smpartm.t4fparttyp   = d4field (t4smpartm.ctref, "FITEMTYP");
    t4smpartm.t4fmpsgrpcd  = d4field (t4smpartm.ctref, "FMPSGRPCD");
    t4smpartm.t4funit      = d4field (t4smpartm.ctref, "FUNIT");
    t4smpartm.t4fqcreq     = d4field (t4smpartm.ctref, "FQCREQ");
    t4smpartm.t4finvchkflg = d4field (t4smpartm.ctref, "FINVCHKFLG");
    t4smpartm.t4fqclt      = d4field (t4smpartm.ctref, "FQCLT");
    t4smpartm.t4fmrpway    = d4field (t4smpartm.ctref, "FMRPWAY");
    t4smpartm.t4flowlvlcd  = d4field (t4smpartm.ctref, "FLOWLVLCD");
    t4smpartm.t4freqrouflg = d4field (t4smpartm.ctref, "FREQROUFLG");
    t4smpartm.t4fvaliddte  = d4field (t4smpartm.ctref, "FVALIDDTE");
    t4smpartm.t4finvaldte  = d4field (t4smpartm.ctref, "FINVALDTE");
    t4smpartm.filter_relate.filter = NULL;
    t4smpartm.filter_relate.relate = NULL;
    t4smpartm.filter_relate.data   = t4smpartm.ctref;
    d4top( t4smpartm.ctref );
    x4init( &t4smpartm.t4filter, t4smpartm.ctref, CTfilter_relate, (void *)&t4smpartm.filter_relate );
    wmsrCTCode.alias[wmsrCTCode.wa] = t4smpartm.ctref;
    d4optimize(t4smpartm.ctref,1);
}

/*----------------------------------------------------------------------------*/
/* �֐���        : t4use_smreqpln                                             */
/* �@�\�T�v      : �\�菊�v�ʂe�̃I�[�v��                                     */
/* ���o�͏��    : I/O Type      Id             ���e                          */
/*                 I   char     *smreqpln_C     �\�菊�v�ʂe�c�a�e��          */
/*                 I   int      exclusive       ۯ����邩�ǂ���               */
/* �֐��l        : �Ȃ�                                                       */
/*----------------------------------------------------------------------------*/
void CMRP32Doc::t4use_smreqpln (char *smreqpln_C, int exclusive)
{
    wmsDspInfo (GetResourceString(WMS_MSG11), smreqpln_C);
    t4smreqpln.ctref = d4open( &wmsrCodebase, smreqpln_C );
    if ( wmsrCTCode.exclusive || exclusive )
        d4lock_file( t4smreqpln.ctref );
    t4smreqpln.t4foyastartd = d4field (t4smreqpln.ctref, "FOYASTARTD");
    t4smreqpln.t4fpartno    = d4field (t4smreqpln.ctref, "FITEMNO");
    t4smreqpln.t4freqseqno  = d4field (t4smreqpln.ctref, "FREQSEQNO");
    t4smreqpln.t4fstrseqno  = d4field (t4smreqpln.ctref, "FSTRSEQNO");
    t4smreqpln.t4fwhcd      = d4field (t4smreqpln.ctref, "FWHCD");
    t4smreqpln.t4fseiban    = d4field (t4smreqpln.ctref, "FPRJNO");
    t4smreqpln.t4freqdte    = d4field (t4smreqpln.ctref, "FREQDTE");
    t4smreqpln.t4fmrpreq    = d4field (t4smreqpln.ctref, "FMRPREQ");
    t4smreqpln.t4foyapartno = d4field (t4smreqpln.ctref, "FOYAITEMNO");
    t4smreqpln.t4foyadued   = d4field (t4smreqpln.ctref, "FOYADUED");
    t4smreqpln.t4foyawhcd   = d4field (t4smreqpln.ctref, "FOYAWHCD");
    t4smreqpln.t4freqdtflg  = d4field (t4smreqpln.ctref, "FREQDTFLG");
    t4smreqpln.t4flowlvlcd  = d4field (t4smreqpln.ctref, "FLOWLVLCD");
	// syuhei 96.07.24
	t4smreqpln.t4fuunit    =  d4field (t4smreqpln.ctref, "FUUNIT");
    t4smreqpln.t4fcorrway  =  d4field (t4smreqpln.ctref, "FCORRWAY");
    t4smreqpln.t4fissway   =  d4field (t4smreqpln.ctref, "FISSWAY");
    t4smreqpln.t4froutseq  =  d4field (t4smreqpln.ctref, "FROUTSEQ");
	t4smreqpln.t4fmrprequnt=  d4field (t4smreqpln.ctref, "FMRPREQUNT");
	// end --96.07.24
    t4smreqpln.t4fentdt     = d4field (t4smreqpln.ctref, "FENTDT");
    t4smreqpln.t4fentusr    = d4field (t4smreqpln.ctref, "FENTUSR");
    t4smreqpln.t4fupdtedt   = d4field (t4smreqpln.ctref, "FUPDTEDT");
    t4smreqpln.t4fupdteusr  = d4field (t4smreqpln.ctref, "FUPDTEUSR");
    t4smreqpln.t4fupdteprg  = d4field (t4smreqpln.ctref, "FUPDTEPRG");
    t4smreqpln.filter_relate.filter = NULL;
    t4smreqpln.filter_relate.relate = NULL;
    t4smreqpln.filter_relate.data   = t4smreqpln.ctref;
    d4top( t4smreqpln.ctref );
    x4init( &t4smreqpln.t4filter, t4smreqpln.ctref, CTfilter_relate, (void *)&t4smreqpln.filter_relate );
    wmsrCTCode.alias[wmsrCTCode.wa] = t4smreqpln.ctref;
    d4optimize(t4smreqpln.ctref,1);
}

/*----------------------------------------------------------------------------*/
/* �֐���        : t4use_smbuckm                                              */
/* �@�\�T�v      : ���Ԃl�̃I�[�v��                                           */
/* ���o�͏��    : I/O Type      Id             ���e                          */
/*                 I   char     *smbuckm_C      ���Ԃl�̂c�a�e��              */
/*                 I   int      exclusive       ۯ����邩�ǂ���               */
/* �֐��l        : �Ȃ�                                                       */
/*----------------------------------------------------------------------------*/
void CMRP32Doc::t4use_smbuckm (char *smbuckm_C, int exclusive)
{
    wmsDspInfo (GetResourceString(WMS_MSG11), smbuckm_C);
    t4smbuckm.ctref = d4open( &wmsrCodebase, smbuckm_C );
    if ( wmsrCTCode.exclusive || exclusive )
        d4lock_file( t4smbuckm.ctref );
    t4smbuckm.t4fkikanno  = d4field (t4smbuckm.ctref, "FKIKANNO");
    t4smbuckm.t4fcaletype = d4field (t4smbuckm.ctref, "FCALETYPE");
    t4smbuckm.t4fstartdte = d4field (t4smbuckm.ctref, "FSTARTDTE");
    t4smbuckm.t4fenddte   = d4field (t4smbuckm.ctref, "FENDDTE");
    t4smbuckm.t4foperdays = d4field (t4smbuckm.ctref, "FOPERDAYS");
    t4smbuckm.filter_relate.filter = NULL;
    t4smbuckm.filter_relate.relate = NULL;
    t4smbuckm.filter_relate.data   = t4smbuckm.ctref;
    d4top( t4smbuckm.ctref );
    x4init( &t4smbuckm.t4filter, t4smbuckm.ctref, CTfilter_relate, (void *)&t4smbuckm.filter_relate );
    wmsrCTCode.alias[wmsrCTCode.wa] = t4smbuckm.ctref;
    d4optimize(t4smbuckm.ctref,1);
}

/*----------------------------------------------------------------------------*/
/* �֐���        : t4use_smmorlsf                                             */
/* �@�\�T�v      : �����I�[�_�[�v�敔�̃I�[�v��                               */
/* ���o�͏��    : I/O Type      Id             ���e                          */
/*                 I   char     *smmorlsf_C     �����I�[�_�[�v�敔�̂c�a�e��  */
/*                 I   int      exclusive       ۯ����邩�ǂ���               */
/* �֐��l        : �Ȃ�                                                       */
/*----------------------------------------------------------------------------*/
void CMRP32Doc::t4use_smmorlsf (char *smmorlsf_C, int exclusive)
{
    wmsDspInfo (GetResourceString(WMS_MSG11), smmorlsf_C);
    t4smmorlsf.ctref = d4open( &wmsrCodebase, smmorlsf_C );
    if ( wmsrCTCode.exclusive || exclusive )
        d4lock_file( t4smmorlsf.ctref );
    t4smmorlsf.t4fmfgodrno  = d4field (t4smmorlsf.ctref, "FMFGODRNO");
    t4smmorlsf.t4fseiban    = d4field (t4smmorlsf.ctref, "FPRJNO");
    t4smmorlsf.t4fpartno    = d4field (t4smmorlsf.ctref, "FITEMNO");
    t4smmorlsf.t4fmfgduedte = d4field (t4smmorlsf.ctref, "FMFGDUEDTE");
    t4smmorlsf.t4fmfgodrqty = d4field (t4smmorlsf.ctref, "FMFGODRQTY");
    t4smmorlsf.t4ftrinwhcd  = d4field (t4smmorlsf.ctref, "FTRINWHCD");
    t4smmorlsf.t4fmfgodrsts = d4field (t4smmorlsf.ctref, "FMFGODRSTS");
    t4smmorlsf.t4fmfgttlrec = d4field (t4smmorlsf.ctref, "FMFGTTLREC");
    t4smmorlsf.filter_relate.filter = NULL;
    t4smmorlsf.filter_relate.relate = NULL;
    t4smmorlsf.filter_relate.data   = t4smmorlsf.ctref;
    d4top( t4smmorlsf.ctref );
    x4init( &t4smmorlsf.t4filter, t4smmorlsf.ctref, CTfilter_relate, (void *)&t4smmorlsf.filter_relate );
    wmsrCTCode.alias[wmsrCTCode.wa] = t4smmorlsf.ctref;
    d4optimize(t4smmorlsf.ctref,1);
}

/*----------------------------------------------------------------------------*/
/* �֐���        : t4use_smuexchg                                             */
/* �@�\�T�v      : �P�ʊ��Z�s�̃I�[�v��                                       */
/* ���o�͏��    : I/O Type      Id             ���e                          */
/*                 I   char     *smuexchg_C     �P�ʊ��Z�s�̂c�a�e��          */
/*                 I   int      exclusive       ۯ����邩�ǂ���               */
/* �֐��l        : �Ȃ�                                                       */
/*----------------------------------------------------------------------------*/
void CMRP32Doc::t4use_smuexchg (char *smuexchg_C, int exclusive)
{
    wmsDspInfo (GetResourceString(WMS_MSG11), smuexchg_C);
    t4smuexchg.ctref = d4open( &wmsrCodebase, smuexchg_C );
    if ( wmsrCTCode.exclusive || exclusive )
        d4lock_file( t4smuexchg.ctref );
    t4smuexchg.t4ffromunit = d4field (t4smuexchg.ctref, "FFROMUNIT");
    t4smuexchg.t4ftounit   = d4field (t4smuexchg.ctref, "FTOUNIT");
    t4smuexchg.t4funexchg  = d4field (t4smuexchg.ctref, "FUNEXCHG");
    t4smuexchg.filter_relate.filter = NULL;
    t4smuexchg.filter_relate.relate = NULL;
    t4smuexchg.filter_relate.data   = t4smuexchg.ctref;
    d4top( t4smuexchg.ctref );
    x4init( &t4smuexchg.t4filter, t4smuexchg.ctref, CTfilter_relate, (void *)&t4smuexchg.filter_relate );
    wmsrCTCode.alias[wmsrCTCode.wa] = t4smuexchg.ctref;
    d4optimize(t4smuexchg.ctref,1);
}

/*----------------------------------------------------------------------------*/
/* �֐���        : t4use_smreqdtf                                             */
/* �@�\�T�v      : �m�菊�v�ʂe�̃I�[�v��                                     */
/* ���o�͏��    : I/O Type      Id             ���e                          */
/*                 I   char     *smreqdtf_C     �m�菊�v�ʂe�̂c�a�e��        */
/*                 I   int      exclusive       ۯ����邩�ǂ���               */
/* �֐��l        : �Ȃ�                                                       */
/*----------------------------------------------------------------------------*/
void CMRP32Doc::t4use_smreqdtf (char *smreqdtf_C, int exclusive)
{
    wmsDspInfo (GetResourceString(WMS_MSG11), smreqdtf_C);
    t4smreqdtf.ctref = d4open( &wmsrCodebase, smreqdtf_C );
    if ( wmsrCTCode.exclusive || exclusive )
        d4lock_file( t4smreqdtf.ctref );
    t4smreqdtf.t4fpmodrflg  = d4field (t4smreqdtf.ctref, "FPMODRFLG");
    t4smreqdtf.t4foyaodrno  = d4field (t4smreqdtf.ctref, "FOYAODRNO");
    t4smreqdtf.t4foyaodrno2 = d4field (t4smreqdtf.ctref, "FOYAODRNO2");
    t4smreqdtf.t4fkopartno  = d4field (t4smreqdtf.ctref, "FKOITEMNO");
    t4smreqdtf.t4fkowhcd    = d4field (t4smreqdtf.ctref, "FKOWHCD");
    t4smreqdtf.t4freqdte    = d4field (t4smreqdtf.ctref, "FREQDTE");
    t4smreqdtf.t4ffirmreq   = d4field (t4smreqdtf.ctref, "FFIRMREQ");
    t4smreqdtf.t4fuunit     = d4field (t4smreqdtf.ctref, "FUUNIT");
    t4smreqdtf.t4fassnsts   = d4field (t4smreqdtf.ctref, "FASSNSTS");
    t4smreqdtf.t4fissttl    = d4field (t4smreqdtf.ctref, "FISSTTL");
    t4smreqdtf.t4fnoreqqty  = d4field (t4smreqdtf.ctref, "FNOREQQTY");
    t4smreqdtf.filter_relate.filter = NULL;
    t4smreqdtf.filter_relate.relate = NULL;
    t4smreqdtf.filter_relate.data   = t4smreqdtf.ctref;
    d4top( t4smreqdtf.ctref );
    x4init( &t4smreqdtf.t4filter, t4smreqdtf.ctref, CTfilter_relate, (void *)&t4smreqdtf.filter_relate );
    wmsrCTCode.alias[wmsrCTCode.wa] = t4smreqdtf.ctref;
    d4optimize(t4smreqdtf.ctref,1);
}

/*----------------------------------------------------------------------------*/
/* �֐���        : t4use_smporlsf                                             */
/* �@�\�T�v      : �w���I�[�_�[�v�敔�̃I�[�v��                               */
/* ���o�͏��    : I/O Type      Id             ���e                          */
/*                 I   char     *smporlsf_C     �w���I�[�_�[�v�敔�̂c�a�e��  */
/*                 I   int      exclusive       ۯ����邩�ǂ���               */
/* �֐��l        : �Ȃ�                                                       */
/*----------------------------------------------------------------------------*/
void CMRP32Doc::t4use_smporlsf (char *smporlsf_C, int exclusive)
{
    wmsDspInfo (GetResourceString(WMS_MSG11), smporlsf_C);
    t4smporlsf.ctref = d4open( &wmsrCodebase, smporlsf_C );
    if ( wmsrCTCode.exclusive || exclusive )
        d4lock_file( t4smporlsf.ctref );
    t4smporlsf.t4fpurodrno  = d4field (t4smporlsf.ctref, "FPURODRNO");
    t4smporlsf.t4fpurodrno2 = d4field (t4smporlsf.ctref, "FPURODRNO2");
    t4smporlsf.t4fpartno    = d4field (t4smporlsf.ctref, "FITEMNO");
    t4smporlsf.t4fseiban    = d4field (t4smporlsf.ctref, "FPRJNO");
    t4smporlsf.t4fpurduedte = d4field (t4smporlsf.ctref, "FPURDUEDTE");
    t4smporlsf.t4fpurodrqty = d4field (t4smporlsf.ctref, "FPURODRQTY");
    t4smporlsf.t4ftrinwhcd  = d4field (t4smporlsf.ctref, "FTRINWHCD");
    t4smporlsf.t4fpurodrsts = d4field (t4smporlsf.ctref, "FPURODRSTS");
    t4smporlsf.t4fpurttlrec = d4field (t4smporlsf.ctref, "FPURTTLREC");
    t4smporlsf.filter_relate.filter = NULL;
    t4smporlsf.filter_relate.relate = NULL;
    t4smporlsf.filter_relate.data   = t4smporlsf.ctref;
    d4top( t4smporlsf.ctref );
    x4init( &t4smporlsf.t4filter, t4smporlsf.ctref, CTfilter_relate, (void *)&t4smporlsf.filter_relate );
    wmsrCTCode.alias[wmsrCTCode.wa] = t4smporlsf.ctref;
    d4optimize(t4smporlsf.ctref,1);
}

/*----------------------------------------------------------------------------*/
/* �֐���        : t4use_smmrperr                                             */
/* �@�\�T�v      : �l�q�o�G���[�e�̃I�[�v��                                   */
/* ���o�͏��    : I/O Type      Id             ���e                          */
/*                 I   char     *smmrperr_C     �l�q�o�G���[�e�̂c�a�e��      */
/*                 I   int      exclusive       ۯ����邩�ǂ���               */
/* �֐��l        : �Ȃ�                                                       */
/*----------------------------------------------------------------------------*/
void CMRP32Doc::t4use_smmrperr (char *smmrperr_C, int exclusive)
{
    wmsDspInfo (GetResourceString(WMS_MSG11), smmrperr_C);
    t4smmrperr.ctref = d4open( &wmsrCodebase, smmrperr_C );
    if ( wmsrCTCode.exclusive || exclusive )
        d4lock_file( t4smmrperr.ctref );
    t4smmrperr.t4ferrcd    = d4field (t4smmrperr.ctref, "FERRCD");
    t4smmrperr.t4ferrno    = d4field (t4smmrperr.ctref, "FERRNO");
    t4smmrperr.t4fpartno   = d4field (t4smmrperr.ctref, "FITEMNO");
    t4smmrperr.t4fstartdte = d4field (t4smmrperr.ctref, "FSTARTDTE");
    t4smmrperr.t4fduedte   = d4field (t4smmrperr.ctref, "FDUEDTE");
    t4smmrperr.t4freqdte   = d4field (t4smmrperr.ctref, "FREQDTE");
    t4smmrperr.t4fqty      = d4field (t4smmrperr.ctref, "FQTY");
    t4smmrperr.filter_relate.filter = NULL;
    t4smmrperr.filter_relate.relate = NULL;
    t4smmrperr.filter_relate.data   = t4smmrperr.ctref;
    d4top( t4smmrperr.ctref );
    x4init( &t4smmrperr.t4filter, t4smmrperr.ctref, CTfilter_relate, (void *)&t4smmrperr.filter_relate );
    wmsrCTCode.alias[wmsrCTCode.wa] = t4smmrperr.ctref;
    d4optimize(t4smmrperr.ctref,1);
}

/*----------------------------------------------------------------------------*/
/* �֐���        : t4use_smsystem                                             */
/* �@�\�T�v      : �V�X�e���^�p��e�̃I�[�v��                               */
/* ���o�͏��    : I/O Type      Id             ���e                          */
/*                 I   char     *smsystem_C     �V�X�e���^�p��e�̂c�a�e��  */
/*                 I   int      exclusive       ۯ����邩�ǂ���               */
/* �֐��l        : �Ȃ�                                                       */
/*----------------------------------------------------------------------------*/
void CMRP32Doc::t4use_smsystem (char *smsystem_C, int exclusive)
{
    wmsDspInfo (GetResourceString(WMS_MSG11), smsystem_C);
    t4smsystem.ctref = d4open( &wmsrCodebase, smsystem_C );
    if ( wmsrCTCode.exclusive || exclusive )
        d4lock_file( t4smsystem.ctref );
    t4smsystem.t4fcurdate   = d4field (t4smsystem.ctref, "FCURDATE");
    t4smsystem.t4fsyscaltyp = d4field (t4smsystem.ctref, "FSYSCALTYP");
    t4smsystem.filter_relate.filter = NULL;
    t4smsystem.filter_relate.relate = NULL;
    t4smsystem.filter_relate.data   = t4smsystem.ctref;
    d4top( t4smsystem.ctref );
    x4init( &t4smsystem.t4filter, t4smsystem.ctref, CTfilter_relate, (void *)&t4smsystem.filter_relate );
    wmsrCTCode.alias[wmsrCTCode.wa] = t4smsystem.ctref;
    d4optimize(t4smsystem.ctref,1);
}

/*----------------------------------------------------------------------------*/
/* �֐���        : t4use_smsystem                                             */
/* �@�\�T�v      : �V�X�e���^�p��e�̃I�[�v��                               */
/* ���o�͏��    : I/O Type      Id             ���e                          */
/*                 I   char     *smsystem_C     �V�X�e���^�p��e�̂c�a�e��  */
/*                 I   int      exclusive       ۯ����邩�ǂ���               */
/* �֐��l        : �Ȃ�                                                       */
/*----------------------------------------------------------------------------*/
void CMRP32Doc::t4use_smmrphst (char *smmrphst_C, int exclusive)
{
    wmsDspInfo (GetResourceString(WMS_MSG11), smmrphst_C);
    t4smmrphst.ctref = d4open( &wmsrCodebase, smmrphst_C );
    if ( wmsrCTCode.exclusive || exclusive )
        d4lock_file( t4smmrphst.ctref );
    t4smmrphst.t4fmrpway    = d4field (t4smmrphst.ctref, "FMRPWAY");
    t4smmrphst.t4fcaletype  = d4field (t4smmrphst.ctref, "FCALETYPE");
    t4smmrphst.t4fmpsgrpcd  = d4field (t4smmrphst.ctref, "FMPSGRPCD");
    t4smmrphst.t4fprodgrpcd = d4field (t4smmrphst.ctref, "FPRODGRPCD");
    t4smmrphst.t4fseiban1   = d4field (t4smmrphst.ctref, "FPRJNO1");
    t4smmrphst.t4fseiban2   = d4field (t4smmrphst.ctref, "FPRJNO2");
    t4smmrphst.t4ffirmkikan = d4field (t4smmrphst.ctref, "FFIRMKIKAN");
    t4smmrphst.t4ffcstkikan = d4field (t4smmrphst.ctref, "FFCSTKIKAN");
    t4smmrphst.t4finvchkflg = d4field (t4smmrphst.ctref, "FINVCHKFLG");
    t4smmrphst.t4fstartllc  = d4field (t4smmrphst.ctref, "FSTARTLLC");
    t4smmrphst.t4fmrpstpllc = d4field (t4smmrphst.ctref, "FMRPSTPLLC");
    t4smmrphst.t4fupdtedt   = d4field (t4smmrphst.ctref, "FUPDTEDT");
    t4smmrphst.t4fupdteusr  = d4field (t4smmrphst.ctref, "FUPDTEUSR");
    t4smmrphst.t4fupdteprg  = d4field (t4smmrphst.ctref, "FUPDTEPRG");
    t4smmrphst.filter_relate.filter = NULL;
    t4smmrphst.filter_relate.relate = NULL;
    t4smmrphst.filter_relate.data   = t4smmrphst.ctref;
    d4top( t4smmrphst.ctref );
    x4init( &t4smmrphst.t4filter, t4smmrphst.ctref, CTfilter_relate, (void *)&t4smmrphst.filter_relate );
    wmsrCTCode.alias[wmsrCTCode.wa] = t4smmrphst.ctref;
    d4optimize(t4smmrphst.ctref,1);
}

/*----------------------------------------------------------------------------*/
/* �֐���        : t4use_smstrctm                                             */
/* �@�\�T�v      : �\���l�̃I�[�v��                                           */
/* ���o�͏��    : I/O Type      Id             ���e                          */
/*                 I   char     *smstrctm_C     �\���l�̂c�a�e��              */
/*                 I   int      exclusive       ۯ����邩�ǂ���               */
/* �֐��l        : �Ȃ�                                                       */
/*----------------------------------------------------------------------------*/
void CMRP32Doc::t4use_smstrctm (char *smstrctm_C, int exclusive)
{
    wmsDspInfo (GetResourceString(WMS_MSG11), smstrctm_C);
    t4smstrctm.ctref = d4open( &wmsrCodebase, smstrctm_C );
    if ( wmsrCTCode.exclusive || exclusive )
        d4lock_file( t4smstrctm.ctref );
    t4smstrctm.t4foyapartno = d4field (t4smstrctm.ctref, "FOYAITEMNO");
    t4smstrctm.t4fstrseqno  = d4field (t4smstrctm.ctref, "FSTRSEQNO");
    t4smstrctm.t4fkopartno  = d4field (t4smstrctm.ctref, "FKOITEMNO");
    t4smstrctm.t4fkoqty     = d4field (t4smstrctm.ctref, "FKOQTY");
    t4smstrctm.t4foyaqty    = d4field (t4smstrctm.ctref, "FOYAQTY");
    t4smstrctm.t4foyaunit   = d4field (t4smstrctm.ctref, "FOYAUNIT");
    t4smstrctm.t4fkounit    = d4field (t4smstrctm.ctref, "FKOUNIT");
    t4smstrctm.t4fstrvlddte = d4field (t4smstrctm.ctref, "FSTRVLDDTE");
    t4smstrctm.t4fstrivldte = d4field (t4smstrctm.ctref, "FSTRIVLDTE");
    t4smstrctm.t4fkowhcd    = d4field (t4smstrctm.ctref, "FKOWHCD");
    t4smstrctm.t4fstrdef    = d4field (t4smstrctm.ctref, "FSTRDEF");
    t4smstrctm.t4fstrlt     = d4field (t4smstrctm.ctref, "FSTRLT");
#ifdef  _WMS_OPTION_    // ��߼�ݔňȍ~
    t4smstrctm.t4foptpartfl = d4field (t4smstrctm.ctref, "FOPTPARTFL");
#endif
    t4smstrctm.filter_relate.filter = NULL;
    t4smstrctm.filter_relate.relate = NULL;
    t4smstrctm.filter_relate.data = t4smstrctm.ctref;
    d4top( t4smstrctm.ctref );
    x4init( &t4smstrctm.t4filter, t4smstrctm.ctref, CTfilter_relate, (void *)&t4smstrctm.filter_relate );
    wmsrCTCode.alias[wmsrCTCode.wa] = t4smstrctm.ctref;
    d4optimize(t4smstrctm.ctref,1);
}

/*----------------------------------------------------------------------------*/
/* �֐���        : t4use_smcodrf                                              */
/* �@�\�T�v      : �󒍂e�̃I�[�v��                                           */
/* ���o�͏��    : I/O Type      Id             ���e                          */
/*                 I   char     *smcodrf_C      �󒍂e�̂c�a�e��              */
/*                 I   int      exclusive       ۯ����邩�ǂ���               */
/* �֐��l        : �Ȃ�                                                       */
/*----------------------------------------------------------------------------*/
void CMRP32Doc::t4use_smcodrf (char *smcodrf_C, int exclusive)
{
    wmsDspInfo (GetResourceString(WMS_MSG11), smcodrf_C);
    t4smcodrf.ctref = d4open( &wmsrCodebase, smcodrf_C );
    if ( wmsrCTCode.exclusive || exclusive )
        d4lock_file( t4smcodrf.ctref );
    t4smcodrf.t4fseiban    = d4field (t4smcodrf.ctref, "FPRJNO");
    t4smcodrf.t4fpartno    = d4field (t4smcodrf.ctref, "FITEMNO");
    t4smcodrf.t4fexfactdte = d4field (t4smcodrf.ctref, "FEXFACTDTE");
    t4smcodrf.t4fcusodrqty = d4field (t4smcodrf.ctref, "FCUSODRQTY");
    t4smcodrf.t4fcusodrflg = d4field (t4smcodrf.ctref, "FCUSODRFLG");
    t4smcodrf.t4fshqty     = d4field (t4smcodrf.ctref, "FSHPQTY");
    t4smcodrf.t4fshpwhcd   = d4field (t4smcodrf.ctref, "FSHPWHCD");
    t4smcodrf.filter_relate.filter = NULL;
    t4smcodrf.filter_relate.relate = NULL;
    t4smcodrf.filter_relate.data   = t4smcodrf.ctref;
    d4top( t4smcodrf.ctref );
    x4init( &t4smcodrf.t4filter, t4smcodrf.ctref, CTfilter_relate, (void *)&t4smcodrf.filter_relate );
    wmsrCTCode.alias[wmsrCTCode.wa] = t4smcodrf.ctref;
    d4optimize(t4smcodrf.ctref,1);
}

/*----------------------------------------------------------------------------*/
/* �֐���        : t4use_smidepf                                              */
/* �@�\�T�v      : �Ɨ����v�e�̃I�[�v��                                       */
/* ���o�͏��    : I/O Type      Id             ���e                          */
/*                 I   char     *smidepf_C      �Ɨ����v�e�̂c�a�e��          */
/*                 I   int      exclusive       ۯ����邩�ǂ���               */
/* �֐��l        : �Ȃ�                                                       */
/*----------------------------------------------------------------------------*/
void CMRP32Doc::t4use_smidepf (char *smidepf_C, int exclusive)
{
    wmsDspInfo (GetResourceString(WMS_MSG11), smidepf_C);
    t4smidepf.ctref = d4open( &wmsrCodebase, smidepf_C );
    if ( wmsrCTCode.exclusive || exclusive )
        d4lock_file( t4smidepf.ctref );
    t4smidepf.t4fpartno    = d4field (t4smidepf.ctref, "FITEMNO");
    t4smidepf.t4fexfactdte = d4field (t4smidepf.ctref, "FEXFACTDTE");
    t4smidepf.t4fidepqty   = d4field (t4smidepf.ctref, "FIDEPQTY");
    t4smidepf.t4fclsflg    = d4field (t4smidepf.ctref, "FCLSFLG");
    t4smidepf.t4fidepstts  = d4field (t4smidepf.ctref, "FIDEPSTTS");
    t4smidepf.t4fidepiss   = d4field (t4smidepf.ctref, "FIDEPISS");
    t4smidepf.t4fshpwhcd   = d4field (t4smidepf.ctref, "FSHPWHCD");
    t4smidepf.filter_relate.filter = NULL;
    t4smidepf.filter_relate.relate = NULL;
    t4smidepf.filter_relate.data   = t4smidepf.ctref;
    d4top( t4smidepf.ctref );
    x4init( &t4smidepf.t4filter, t4smidepf.ctref, CTfilter_relate, (void *)&t4smidepf.filter_relate );
    wmsrCTCode.alias[wmsrCTCode.wa] = t4smidepf.ctref;
    d4optimize(t4smidepf.ctref,1);
}
/*=====< At Eof T4USE.C >=====================================================*/



