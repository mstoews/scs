/*============================================================================*/
/* T4EXTERN.H : MRP�W�J����Extern�錾ͯ��                                     */
/* �@�\�T�v   : MRP�W�J�����Ŏg�p����֐���O���ϐ���Extern�錾����̧��       */
/* �쐬��     : �s��                                                          */
/* �쐬��     : ��    ��                                                      */
/* �C����     : 1995.06.23                                                    */
/* �C����     : �k��  �O                                                      */
/*============================================================================*/
#ifndef __MRPEXT_H
#define __MRPEXT_H

//#define CTBOR_DEF


/*----- MRP�װ���� -----*/
#define WMS_MRPERR_DT1  (char *)"01"            // ���t�װ(MPS�����ߋ���)
#define WMS_MRPERR_DT2  (char *)"02"            // ���t�װ(�[��/��������ߋ���)
#define WMS_MRPERR_POD  (char *)"03"            // �i�ڎ�z�Ǘ������
#define WMS_MRPERR_SUP  (char *)"04"            // �i�ڋ����S��������񖳂�
#define WMS_MRPERR_WHC  (char *)"05"            // �i�ڊ�{�݌ɏꏊ��񖳂�
#define WMS_MRPERR_CLT  (char *)"06"            // ����ް����(���t������ް�ɖ��o�^)
#define WMS_MRPERR_UN1  (char *)"07"            // �P�ʊ��Z�װ(�e�\��)
#define WMS_MRPERR_UN2  (char *)"08"            // �P�ʊ��Z�װ(�q�\��)

#define T4POS               (23)
#define WMS_MAXLEVEL        (99)                // MAX۰���ٺ���
#define WMS_LANG_FILE       ("S3221020.LNG")    // ����i�[̧�ٖ�
#define WMS_PRGID           ("S3221020")        // �v���O�����h�c

/*----------------------------------------------------------------------------*/
/* ��Ɨ̈�ԍ��ݒ�                                                           */
/*----------------------------------------------------------------------------*/
#define WMS_WA_SMPRTODR     (1)                 // �i�ڎ�z�Ǘ��M
#define WMS_WA_SMPLNODR     (2)                 // �v�浰�ްF
#define WMS_WA_SMCALEM      (3)                 // ����ްM
#define WMS_WA_SMPARTM      (4)                 // �i�ڊM
#define WMS_WA_SMREQPLN     (5)                 // �\�菊�v��F
#define WMS_WA_SMBUCKM      (6)                 // ����M
#define WMS_WA_SMMPSF       (7)                 // ����Y�v��
#define WMS_WA_SMMORLSF     (8)                 // �������ް(�v�敔)
#define WMS_WA_SMPRTQCM     (9)                 // �i�ڌ����M
#define WMS_WA_SMSECTM      (10)                // ����M
#define WMS_WA_SMUEXCHG     (11)                // �P�ʊ��ZT
#define WMS_WA_SMINVDTF     (12)                // �݌ɖ���F
#define WMS_WA_SMREQDTF     (13)                // �m�菊�v��F
#define WMS_WA_SMCODRF      (13)                // �󒍂e
#define WMS_WA_SMIDEPF      (13)                // �Ɨ����v�e
#define WMS_WA_SMPRTINV     (13)                // �i�ڍ݌ɊǗ��M
#define WMS_WA_SMPORLSF     (14)                // �w�����ް(�v�敔)
#define WMS_WA_SMMRPERR     (15)                // MRP�װF
#define WMS_WA_SMSYSTEM     (16)                // ���щ^�p�F
#define WMS_WA_SMMRPHST     (16)                // MRP�W�J����F
#define WMS_WA_SMSECTTY     (16)                // ��������T
#define WMS_WA_SMSTRCTM     (17)                // �\��M


/*----------------------------------------------------------------------------*/
/* �֐��̌^�錾                                                               */
/*----------------------------------------------------------------------------*/
// in S3221020.CPP
extern char *GetResourceString (int);
// in MRPPRC.C
/*
extern void wmsMrpInit (void);
extern void wmsMrpExit (void);
extern void wmsGetCurrentItemInfo (char *, char *, char *);
extern void wmsGetCurrentItemInfo2 (long *, long *, char *, char *, char *, char *, char *);
extern BOOL wmsGetCurrentItemOdrInfo (char *, char *, long *, long *, double *, double *, double *, double *);
extern BOOL wmsGetCurrentItemSupplierInfo (char *, char *, char *);
extern void wmsGetCurrentItemQcInfo (char *, char *, char *, long *);
extern BOOL wmsGetCurrentItemWhInfo (char *, char *, char *);
extern void wmsDspInfo (char *, char *);
extern void wmsDspItemCnt (char *, char *);
extern BOOL wmsAllocArray (int);
extern void wmsFreeArray (void);
extern void wmsZap (DATA4 *);
extern void wmsOpenFile (void);
extern void wmsOpenFile2 (void);
extern void t4_s_datset (long);
extern void t4_s_rdtread (void);
extern void t4_s_codread (void);
extern void t4_s_irdread (void);
extern long t4_s_mps_search (char *, char *);
extern long t4_s_req_search (char *);
extern long t4_s_mpsread (char *);
extern int  t4_s_crepln (char *, char *, char *, double);
extern int  wmsKoReqExp (void);
extern int  t4_s_mrpcl (void);
extern void t4_s_greqset (void);
extern void t4_s_modread (void);
extern void t4_s_podread (void);
extern int  t4_s_nrset (void);
extern void t4_s_mrphst (char *);
extern void t4_s_unitchg (void);
extern int  wmsChkMrpWay (char *);
extern int  wmsLTSet (char *, char *, char *, long);
extern int  wmsWDateSet (char *, char *, char *, long);
extern void t4_s_SetMrpErr (char *, char *, double, char *);
// extern int  wmsErsNgDataFromReqPln (void);
extern char *wmsSetStr (char *, char *, unsigned int);
extern char *wmsDate4Assign (char *, long);
extern char *wmsDate4Today (char *);
extern char *wmsDate4Time_Now (char *);
extern void wmsSetUpdateDate (FIELD4 *, FIELD4 *, FIELD4 *, FIELD4 *, FIELD4 *);
extern double wmsRaiseQty (double qty, int dec); // syuhei 96.07.24
extern double wmsRoundQty (double qty, int dec); // syuhei 96.07.27
// in T4USE.C
extern void t4use_smmpsf (char *, int);
extern void t4use_smsectm (char *, int);
extern void t4use_smsectty (char *, int);
extern void t4use_smprtqcm (char *, int);
extern void t4use_sminvf (char *, int);
extern void t4use_sminvdtf (char *, int);
extern void t4use_smprtinv (char *, int);
extern void t4use_smprtodr (char *, int);
extern void t4use_smplnodr (char *, int);
extern void t4use_smcalem (char *, int);
extern void t4use_smpartm (char *, int);
extern void t4use_smreqpln (char *, int);
extern void t4use_smbuckm (char *, int);
extern void t4use_smmorlsf (char *, int);
extern void t4use_smuexchg (char *, int);
extern void t4use_smreqdtf (char *, int);
extern void t4use_smporlsf (char *, int);
extern void t4use_smmrperr (char *, int);
extern void t4use_smsystem (char *, int);
extern void t4use_smmrphst (char *, int);
extern void t4use_smstrctm (char *, int);
extern void t4use_smcodrf (char *, int);
extern void t4use_smidepf (char *, int);
*/
/*----------------------------------------------------------------------------*/
/* �O���ϐ���extern�錾                                                       */
/*----------------------------------------------------------------------------*/
extern DATA4        *c4browse_dbf;
extern T4SMMPSF     t4smmpsf;
extern T4SMSECTM    t4smsectm;
extern T4SMSECTTY   t4smsectty;
extern T4SMPRTQCM   t4smprtqcm;
extern T4SMINVDTF   t4sminvdtf;
extern T4SMPRTINV   t4smprtinv;
extern T4SMPRTODR   t4smprtodr;
extern T4SMPLNODR   t4smplnodr;
extern T4SMCALEM    t4smcalem;
extern T4SMPARTM    t4smpartm;
extern T4SMREQPLN   t4smreqpln;
extern T4SMBUCKM    t4smbuckm;
extern T4SMMORLSF   t4smmorlsf;
extern T4SMUEXCHG   t4smuexchg;
extern T4SMREQDTF   t4smreqdtf;
extern T4SMPORLSF   t4smporlsf;
extern T4SMMRPERR   t4smmrperr;
extern T4SMSYSTEM   t4smsystem;
extern T4SMMRPHST   t4smmrphst;
extern T4SMSTRCTM   t4smstrctm;
extern T4SMCODRF    t4smcodrf;
extern CODE4        wmsrCodebase;                   // CodeBase��Ɗ�
extern CTCODE       wmsrCTCode;                     // ������ޕϊ�°ٍ�Ɗ�
extern char         wmsrSysDate[CTDATE];            // ���ѓ��t
extern char         wmsrSysCTyp[CTSTR_LEN];         // ���Ѷ��������
extern char         wmsrCaleTyp[CTSTR_LEN];         // ���Ķ��������
extern char         wmsrSttDate[CTDATE];            // �v�浰�ް�����
extern char         wmsrDueDate[CTDATE];            // �v�浰�ް������
extern char         wmsrNullDate[CTDATE];           // ���t�^��NULL�l
extern int          wmsrLanguageNumber;             // ����No.
extern HINSTANCE    hInst;                          // MRP���ع���ݲݽ�ݽ
extern T4SMIDEPF    t4smidepf;
extern long         s_r_nm_N;
extern double       s_r_nrqty_F;
extern long         m_N;
extern long         vl_cnt_N;
extern double       s_r_invqty_F;
extern double       s_r_ohqty_F;
extern double       vl_qty_F;
extern long         s_r_reqdno_N;
extern double       s_r_reqqty_F;
extern long         s_r_recno_N;
extern double       s_r_plnqty_F;
extern double       s_r_safe_F;                     // ���S�݌ɐ�
extern double       s_r_loss_F;                     // �����݌ɐ�
extern char         s_r_cmpdat_D[CTDATE];
extern char         s_r_seiban_C[CTSTR_LEN];
extern char         s_r_whcdcl_C[CTSTR_LEN];
extern char         qc_caltyp_C[CTSTR_LEN];
extern char         s_r_pmflg_C[CTSTR_LEN];
extern char         s_r_mrpavl_C[CTSTR_LEN];
extern long         s_r_roundd_N;
extern char         s_r_odrule_C[CTSTR_LEN];
extern double       s_r_odrdef_F;
extern double       s_r_round_F;
extern double       s_r_maxqty_F;
extern double       s_r_minqty_F;
extern long         s_r_odrlt_N;
extern char         s_r_whcd_C[CTSTR_LEN];
extern char         s_r_prmwcd_C[CTSTR_LEN];
extern long         s_r_qclt_N;
extern char         s_r_unit_C[CTSTR_LEN];
extern char         s_r_avlflg_C[CTSTR_LEN];
extern long         s_r_mpsend_N;
extern char         s_r_way_C[CTSTR_LEN];
extern char         s_r_partno_C[CTSTR_LEN];
extern double       *rd_F;
extern double       *mps_F;
extern double       *vl_F;
extern char         **dte_D;
extern double       *plo_F;
extern double       *od_F;
extern double       *gr_F;
extern double       *oyareq1_F;
extern double       *oyareq2_F;
extern char         **start1_D;
extern char         **start2_D;
extern char         **partno1_C; 
extern char         **partno2_C;   
extern long         n_N;
extern long         n_vl_N;
extern long         vl_tim_N;
extern long         days_N;
extern long         s_r_sysdno_N;
extern char         s_r_fcstdt_D[CTDATE];
extern char         s_r_firmdt_D[CTDATE];
extern char         s_r_tseibn_C[CTSTR_LEN];
extern char         s_r_fseibn_C[CTSTR_LEN];
extern char         s_r_progcd_C[CTSTR_LEN];
extern char         s_r_mrpway_C[CTSTR_LEN];
extern char         s_r_invchk_C[CTSTR_LEN];
extern long         l_N;
extern char         s_r_tounit_C[CTSTR_LEN];
extern char         s_r_fromunit_C[CTSTR_LEN];
extern double       s_r_chg_F;
extern long         s_r_errno_L;                    // MRP�װ�ԍ�
extern int          wmsrDateLength;                 // ���t�̒���
extern char         wmsrUsrId[CTSTR_LEN];           // ���[�U�h�c

extern char         wmsrSttDate[CTDATE];            // �v�浰�ް����� (�␳��) 1996.02.07 (718��)
extern char         wmsrSttDateOrg[CTDATE];         // �v�浰�ް����� (�␳�O) 1996.02.07 (718��)
extern char         s_r_mpsflag_C[CTSTR_LEN];       // syuhei 96.07.24

#endif
/*=====< At Eof T4EXTERN.H >==================================================*/
